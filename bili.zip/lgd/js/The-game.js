$(function(){
	$(".l-wml-a").click(function() {
		$(".l-wml-a").eq($(this).index()).addClass("l-wml-a-x").siblings().removeClass("l-wml-a-x");
		$(".l-wmlm-main").eq($(".l-wml-a")
			.index(this)).addClass("l-wmlm-main-x").siblings().removeClass("l-wmlm-main-x")
	});
})