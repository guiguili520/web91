$(function() {
	$(".l-l-r-t-d").click(function() {
		$(".l-l-r-t-d").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-x").click(function() {
		$(".l-l-r-m-cen").removeClass("l-l-r-m-cen-y  l-l-r-m-cen-z ");
	});
	$(".l-y").click(function() {
		$(".l-l-r-m-cen").addClass("l-l-r-m-cen-y").removeClass("l-l-r-m-cen-x  l-l-r-m-cen-z");
	});
	$(".l-z").click(function() {
		$(".l-l-r-m-cen").addClass("l-l-r-m-cen-z").removeClass("l-l-r-m-cen-x l-l-r-m-cen-y");
	});
	$(".l-l-l-div2-x").click(function() {
		$(".l-l-l-div2-x").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
		$(".l-main-x").eq($(".l-l-l-div2-x")
			.index(this)).addClass("l-main-y").siblings().removeClass("l-main-y")
	});
	$(".l-l-table-x").click(function() {
		$(".l-l-table-x").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
		$(".l-l-r-main2-cen").addClass("l-l-r-main2-cen-x");
	});
	$(".l-l-r-ul-x").click(function() {
		$(".l-l-r-main2-cen").addClass("l-l-r-main2-cen-x").removeClass("l-l-r-main2-cen-y");
	})
	$(".l-l-r-ul-y").click(function() {
		$(".l-l-r-main2-cen").addClass("l-l-r-main2-cen-y").removeClass("l-l-r-main2-cen-x");
	})
	//番剧
	$(".l-Hpltd-div").click(function() {
		$(".l-Hpltd-div").eq($(this).index()).addClass("l-Hpltd-div-on").siblings().removeClass("l-Hpltd-div-on");
		$(".l-Hpl-main-x").eq($(".l-Hpltd-div")
			.index(this)).addClass("l-Hpl-main-y").siblings().removeClass("l-Hpl-main-y")
	});

	$(".l-fj-x").click(function() {
		$(".l-fj-x").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});

	$(".l-hp-x").click(function() {
		$(".l-hp-x").eq($(this).index()).addClass("l-Hpltd-div-on").siblings().removeClass("l-Hpltd-div-on");
	});
	$(".l-lll-lx").click(function() {
		$(".l-lll-lx").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	//
	$(".l-l-l-b").click(function() {
		$(".l-l-l-b").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lc").click(function() {
		$(".l-lc").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-ld").click(function() {
		$(".l-ld").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-le").click(function() {
		$(".l-le").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lf").click(function() {
		$(".l-lf").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lg").click(function() {
		$(".l-lg").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lh").click(function() {
		$(".l-lh").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-li").click(function() {
		$(".l-li").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lj").click(function() {
		$(".l-lj").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lk").click(function() {
		$(".l-lk").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-ll").click(function() {
		$(".l-ll").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lm").click(function() {
		$(".l-lm").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-ln").click(function() {
		$(".l-ln").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lo").click(function() {
		$(".l-lo").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lp").click(function() {
		$(".l-lp").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	$(".l-lq").click(function() {
		$(".l-lq").eq($(this).index()).addClass("l-on").siblings().removeClass("l-on");
	});
	//星期
	$(".l-Hpltd-div").click(function() {
		$(this).children().addClass("l-Hpltd-div-x");
		$(this).siblings().children().removeClass("l-Hpltd-div-x")
	});
	//app下载
	$(".l-app-i").click(function(){
		$(".l-app").remove().html();
	});
});