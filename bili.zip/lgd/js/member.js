$(function() {
	//
	$(".l-j-mora-span").click(function() {
		$(".l-j-mora-span").eq($(this).index()).addClass("l-j-span").siblings().removeClass("l-j-span");
		$(".l-li-more-div-bottom").eq($(".l-j-mora-span")
			.index(this)).addClass("l-li-more-div-bottom-x").siblings().removeClass("l-li-more-div-bottom-x")
	});
	//
	$(".l-li-more-div").hide();
	$('.l-li-more>a').click(function(event) {
//		event.stopPropagation(); 
		$(this).siblings().toggle();	
	});
		var num= 2;
	$(".l-li-more>a").click(function(){	
		if(num%2==0){
			$(this).css("color","#F25D8E");
			$(this).children("i").css("transform","rotate(-90deg)");
			num++;
		}else{
			$(this).css("color","#6d757a");
			$(this).children("i").css("transform","rotate(90deg)");
			num++;
		}
	})
});